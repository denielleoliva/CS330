public interface TransactionBehavior {
    public void transaction();
}
