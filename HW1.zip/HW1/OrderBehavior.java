public interface OrderBehavior {
    public void generateOrder();
}
