public class BalsamFir extends Tree{
    
    public BalsamFir(){
        description = "Balsam Fir is decorated with ";
    }

    public int cost(){
        return 5;
    }
    
}
