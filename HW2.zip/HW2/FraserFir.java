public class FraserFir extends Tree{
    
    public FraserFir(){
        description = "Fraser Fir is decorated with ";
    }

    public int cost(){
        return 12;
    }

}
