public class ColoradoBlueSpruce extends Tree{
    
    public ColoradoBlueSpruce(){
        description = "Blue Spruce is decorated with ";
        
    }

    public int cost(){
        return 20;
    }
    
}
