public class DouglasFir extends Tree{
    
    public DouglasFir(){
        description = "Douglas Fir is decorated with ";
    }

    public int cost(){
        return 15;
    }
    
}
