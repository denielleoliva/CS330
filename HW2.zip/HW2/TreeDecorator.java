

public abstract class TreeDecorator extends Tree {
    Tree christmasTree;
    

    public abstract String getDescription();
}
